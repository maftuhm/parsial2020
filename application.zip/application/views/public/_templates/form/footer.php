<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
            </div>

        <footer>
            <p>&copy; Parsial 2020 | All Rights Reserved</p>
        </footer>
        <script type="text/javascript" src="<?php echo base_url($plugins_dir . '/sweetalert2/sweetalert2.min.js'); ?>"></script>
        <?php echo $alert_modal;?>
    </body>
</html>