<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
			<!-- banner -->
			<div class="banner_w3lspvt-2">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html" class="font-weight-bold">Home</a></li>
					<li class="breadcrumb-item" aria-current="page">404 Error Page</li>
				</ol>
			</div>
			<!-- //banner -->
		</div>
		<!-- //main banner -->

		<!-- 404 -->
		<div class="error pb-5 pt-2 text-center" id="price">
			<div class="container pb-xl-5 pb-lg-3">
				<img src="<?php echo base_url($templates_dir . '/images/error.png'); ?>" alt="" class="img-fluid" />
				<h3 class="title-w3 text-bl my-3 font-weight-bold text-capitalize">Oops! This page can’t be found.</h3>
				<p class="sub-tittle text-center4">Sed do eiusmod tempor incididunt ut labore et dolore magna
					aliqua. Ut enim ad minim veniam, quis nostrud exercitation</p>
				<a href="index.html" class="btn button-style mt-5">Back To Home</a>
			</div>
		</div>
		<!-- //404 -->