Material Design Flat Avatar Set by Dimitrios Pantazis
http://www.oxygenna.com/news/material-design-flat-avatar-set