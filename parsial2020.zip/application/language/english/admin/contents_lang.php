<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['contents_action']              = 'Action';
$lang['contents_active']              = 'Active';
$lang['contents_create']         	  = 'Create content';
$lang['contents_created_on']          = 'Created on';
$lang['contents_name']		          = 'Name';
$lang['contents_title']		          = 'Title';
$lang['contents_description']         = 'Description';
$lang['contents_slug']		          = 'Slug';
$lang['contents_quest']				  = 'Question';
$lang['contents_quest_type']		  = 'Type';
$lang['contents_n_quest']		      = 'Number of question';
$lang['contents_deactivate_question'] = 'Are you sure you want to deactivate the content %s';
$lang['contents_edit']           	  = 'Edit content';
$lang['contents_status']              = 'Status';
